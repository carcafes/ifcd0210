
package crud;

import Controlador.CtrlProducto;
import Modelo.ConsultasProducto;
import Modelo.Producto;
import Vista.FrmProducto;



public class CRUD {

    
    public static void main(String[] args) {
        Producto mod =new Producto();
        ConsultasProducto modc = new ConsultasProducto();
        FrmProducto frm = new FrmProducto();
        
        CtrlProducto ctrl = new CtrlProducto(mod,modc,frm);
        ctrl.iniciar();
        frm.setVisible(true);
    }
    
}
