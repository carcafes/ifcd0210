
package Controlador;

import Modelo.ConsultasProducto;
import Modelo.Producto;
import Vista.FrmProducto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class CtrlProducto implements ActionListener {
    
    private Producto mod;
    private ConsultasProducto modC;
    private FrmProducto frm;
            
    public CtrlProducto(Producto mod, ConsultasProducto modC,FrmProducto frm){
        
        this.mod=mod;
        this.modC = modC;
        this.frm = frm;
        this.frm.btnBuscar.addActionListener(this);
        this.frm.btnCrear.addActionListener(this);
        this.frm.btnModificar.addActionListener(this);
        this.frm.btnLimpiar.addActionListener(this);
        this.frm.btnEliminar.addActionListener(this);
    }
    public void iniciar(){
    frm.setTitle("Tienda");
    modC.droptabla();
    modC.tabla();
    frm.txtid.setVisible(false);
    
    
    
    }
    @Override
    public void actionPerformed(ActionEvent e){
    if(e.getSource() == frm.btnCrear){
    
    mod.setCodigo(Integer.parseInt(frm.txtCodigo.getText()));
    mod.setNombre(frm.txtNombre.getText());
    mod.setPrecio(Double.parseDouble(frm.txtPrecio.getText()));
    mod.setStock(Integer.parseInt(frm.txtStock.getText()));
    if(modC.crear(mod)){
        JOptionPane.showMessageDialog(null,"Registro guardado");
        limpiar();
    }else{
        JOptionPane.showMessageDialog(null,"Error al guardar");
        limpiar();}
    }
    //--------------------------------------------------------------------------
    if(e.getSource() == frm.btnModificar){
    mod.setId(Integer.parseInt(frm.txtid.getText()));
    mod.setCodigo(Integer.parseInt(frm.txtCodigo.getText()));
    mod.setNombre(frm.txtNombre.getText());
    mod.setPrecio(Double.parseDouble(frm.txtPrecio.getText()));
    mod.setStock(Integer.parseInt(frm.txtStock.getText()));
    if(modC.modificar(mod)){
        JOptionPane.showMessageDialog(null,"Modificacion completa");
        limpiar();
    }else{
        JOptionPane.showMessageDialog(null,"Error al modificar");
        limpiar();}
    }
    //--------------------------------------------------------------------------
    if(e.getSource() == frm.btnEliminar){
    mod.setCodigo(Integer.parseInt(frm.txtCodigo.getText()));
   
    if(modC.eliminar(mod)){
        JOptionPane.showMessageDialog(null,"Eliminacion completa");
        limpiar();
    }else{
        JOptionPane.showMessageDialog(null,"Error al eliminar");
        limpiar();}
    }
    //--------------------------------------------------------------------------
    if(e.getSource() == frm.btnBuscar){
        
    mod.setCodigo(Integer.parseInt(frm.txtCodigo.getText()));
   
    if(modC.buscar(mod)){
        frm.txtid.setText(String.valueOf(mod.getId()));
        frm.txtCodigo.setText(String.valueOf(mod.getCodigo()));
        frm.txtNombre.setText(mod.getNombre());
        frm.txtPrecio.setText(String.valueOf(mod.getPrecio()));
        frm.txtStock.setText(String.valueOf(mod.getStock()));
        
    }else{
        JOptionPane.showMessageDialog(null,"No se encontro el resultado");
        limpiar();}
    }
    //--------------------------------------------------------------------------
    if(e.getSource() == frm.btnLimpiar){
        limpiar();
    }
    }
    //--------------------------------------------------------------------------
    
    public void limpiar(){
        frm.txtid.setText("");
        frm.txtCodigo.setText(null);
        frm.txtNombre.setText(null);
        frm.txtPrecio.setText(null);
        frm.txtStock.setText(null);
    }
}
