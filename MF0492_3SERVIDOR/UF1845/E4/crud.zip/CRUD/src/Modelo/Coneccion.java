
package Modelo;


import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Coneccion {
    public String driver ="com.mysql.jdbc.Driver";
    public final String base = "e4";
    public final String user = "root";
    public final String password = null;
    public final String url = "jdbc:mysql://localhost:3306/e4";
    private Connection con = null;
    public Connection getConeccion(){ 
        
        try{
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url,user,password);
        
        }
        catch(SQLException e){
        System.err.print(e);
        }
        catch (ClassNotFoundException ex) {
            Logger.getLogger(Coneccion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
    
    
}
