/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Webapp;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author pc
 */
@WebServlet(name = "Saludar", urlPatterns = {"/Saludar"})
public class NewServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title> Prueba UF1844_3 </title>");
            out.println("<link type=\"text/css\" rel=\"stylesheet\" href=\"./css/estilos.css\" />");           
            out.println("</head>");
            out.println("<body>");
            out.println("<div class=\"fondo\">\n" +
"        <div class=\"fondo-negro sombreado\">\n" +
"            <header id=\"my-header\" class=\"sombreado\">\n" +
"                El sistema solar:  \n" +
"            </header>\n" +
"            \n" +
"            <div class=\"contenido\">\n" +
"                <p>\n" +
"                    <h1>Mercurio.</h1><br />\n" +
"                    <div id=\"mercurio\"></div>\n" +
"                    El primer planeta del sistema solar,su temperatura media es de 160 ºC, llegando a los -180 ºC en la noche y a los 430 ºC durante el día. Su tamaño es de 4.880 km, menos de la mitad que la tierra y se encuentra a una distancia de 57.910.000 km del sol.Color Gris dado a su composicion de rocas y es uno de los planetas solidos, como todos a este lado del cinturon de asteroides.\n" +
"                    <br /><br />\n" +
"                    Curiosidad: Es el planeta más próximo al Sol, pero no es el más caliente como se podría pensar.\n" +
"                </p>\n" +
"                <p>\n" +
"                    <h1>Venus.</h1><br />\n" +
"                    <div id=\"venus\"></div>\n" +
"                    Aun siendo el segundo planeta más cerca del sol es el planeta más caliente del sistema solar, su temperatura en su superficie puede llegar a alcanzar los 465 ºC. Tiene un tamaño de 12.104 km, bastante similar a la tierra y esta a 108.200.000 km del sol. Su densa atmosfera causa un gran efecto invernadero, del que deriva la temperatura, y a la vez le da ese color amarillento. En la superficie las altas temperaturas podrian llegar a fundir incluso plomo. Tambien es un planeta solido,dado que esta hecho principamente de solidos.\n" +
"                    <br /><br />\n" +
"                    Curiosidad: El eje sobre el que rota el planeta es casi horizontal,lo que causa que tarde unos 400 años en pasar un dia.\n" +
"                </p>\n" +
"                <p>\n" +
"                    <h1>Tierra.</h1><br />\n" +
"                    <div id=\"tierra\"></div>\n" +
"                    Nuestro planeta tiene una temperatura media de 15 ºC y subiendo. El tamaño es de 12.756 km y se encuentra a una distancia de 149.600.000 km. EL 70% de su superficie esta cubierta de agua lo que le da ese color azul y ayuda a regular la temperatura,destaca la presencia de vida y el impacto que tiene sobre el aspecto del planeta.Tambien es un planeta solido.\n" +
"                    <br /><br />\n" +
"                    Curiosidad Unico planeta habitado conocido.\n" +
"                </p>\n" +
"                <p>\n" +
"                    <h1>Marte.</h1><br />\n" +
"                    <div id=\"marte\"></div>\n" +
"                    El planeta rojo tiene temperaturas extremas,varian desde los 20 ºC hasta los -140 ºC. Siendo mas pequeño que la tierra y venus midiendo practicamente la mitad de la tierra con un tamaño de 6.794 km. Es el ultimo planeta antes del cinturon de asteroides y esta a 227.940.000 km del sol.Un planeta bastante pequeño cubierto en un 70%,casi lo mismo que de agua en la tierra, de desiertos de piedras y oxido, los cuales le dan su color.\n" +
"                    <br /><br />\n" +
"                    Curiosidad:Se han descubierto enormes cantidades de agua bajo el suelo en forma de hielo.\n" +
"                </p>\n" +
"                <p>\n" +
"                    <h1>Júpiter.</h1><br />\n" +
"                    <div id=\"jupiter\"></div>\n" +
"                    Primer planeta despues del cinturon de asteroides,con una temperatura mínima de -163 ºC y una temperatura máxima de 121 ºC. Su tamaño 142.984 km lo vuelve el planeta mas grande del sistema solar, se encuentra a 778.330.000 km del sol.Su color va desde el amarillo pardo hasta el rojizo a franjas horizontales. Es el primer planeta gaseoso del sistema solar, siendo que la mayor parte de planeta es la densa atmosfera.\n" +
"                    <br /><br />\n" +
"                    Curiosidad: El famoso lunar de jupiter es una tormenta tan grande y potente que se alimenta a si misma.Tambien tiene auroras boreales.\n" +
"                </p>\n" +
"                <p>\n" +
"                    <h1>Saturno.</h1><br />\n" +
"                    <div id=\"saturno\"></div>\n" +
"                    A esta distancia los planetas ya empiezan a ser muy fríos, la temperatura minina es de –191.15 °C y la máxima -130.15 ºC.Con un tamaño de 108.728 km y distancia: 1.429.400.000 km.Sus colores van entre naranja y blanco a franjas horizontales y es de tipo gaseoso.\n" +
"                    <br /><br />\n" +
"                    Curiosidad: Sus famosos anillos estan hechos por reflejos de polvo y hielo que giran en torno al planeta.\n" +
"                </p>\n" +
"                <p>\n" +
"                    <h1>Urano.</h1><br />\n" +
"                    <div id=\"urano\"></div>\n" +
"                    Es un lugar muy frío, la temperatura media es de unos terribles -205 ºC.\n" +
"                    Su tamaño es de 51.118 km y su distancia es de 2.870.990.000 km del sol.\n" +
"                    Su color es Azul turquesa y es de tipo gaseoso.\n" +
"                    <br /><br />\n" +
"                    Curiosidad: Su atmosfera esta hecha de agua y metano, lo que le da ese color.\n" +
"                </p>\n" +
"                <p>\n" +
"                    <h1>Neptuno.</h1><br />\n" +
"                    <div id=\"neptuno\"></div>\n" +
"                    Es el planeta más lejano del sistema solar, con lo que recibe menos radiación, siendo la temperatura media en su superficie la friolera de -218 ºC.Tiene un tamaño de 49.532 km y una distancia al sol de 504.300.000 km.Tiene una atmosfera azul debido a su composicion gaseosa.\n" +
"                    <br /><br />\n" +
"                    Curiosidad: Los cientificos creen que las condiciones de la atmosfera hacen que se formen diamantes y lluevan hacia el centro.\n" +
"                </p>\n" +
"            </div>\n" +
"            <footer id=\"my-footer\" class=\"sombreado\">\n" +
"                \n" +
"            <div class=\"contacto\">Hecho por:<br /></div>\n" +
"            Carlos Javier Cosme Melian<br />\n" +
"            \n" +
"            \n" +
"        </footer>\n" +
"        </div>\n" +
"        \n" +
"    </div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
